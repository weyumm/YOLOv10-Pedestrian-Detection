# yolov10person > 2024-08-09 1:52pm
https://universe.roboflow.com/test-ml6ty/yolov10person

Provided by a Roboflow user
License: CC BY 4.0

